# My Walk With Jehovah — free Android-friendly app

## What is included
- Daily Bible-based encouragement and a practical goal
- Official Daily Text link to jw.org
- Bible-reading and personal-study notes saved on the device
- Morning (05:30), midday (12:30), and evening (20:00) reminder settings
- Student-life guidance for friends, peer pressure, time, honesty, and stress
- Daily habit checklist and weekly reflection
- Installable Progressive Web App (PWA) with offline caching after first load

## Important reminder limitation
The reminder times are saved, and the app can trigger browser notifications while it remains open. Android browsers generally do not guarantee that ordinary webpage timers will fire after the browser is closed or the phone restarts. A fully reliable background alarm requires a native Android app or a push-notification/scheduling service. Do not rely on this first version for critical alarms.

## Phone-only setup (recommended: GitHub Pages)
You can do these steps using the phone browser. No laptop or Node.js is required.

1. Download and extract `my-walk-with-jehovah.zip` on your phone. The project contains `index.html`, `manifest.json`, `sw.js`, and icons.
2. Sign in or create a GitHub account at https://github.com.
3. Create a new **public** repository named `my-walk-with-jehovah`.
4. Upload the files inside the extracted project folder to the repository root (not the ZIP itself).
5. In the repository, open **Settings → Pages**. Under build/deployment, choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
6. Wait for GitHub Pages to publish. Open the published HTTPS URL shown in Settings → Pages.
7. In Chrome on Android, open the published site. Tap the three-dot menu → **Add to Home screen** or **Install app**.
8. Open the installed app, go to **My Routine**, confirm 05:30, 12:30, and 20:00, tap **Save reminder times**, then tap **Allow notifications** if the browser offers it.
9. For the best chance of notifications, keep the app open. Android battery optimization and browser behavior may affect delivery.

## Using it
- **Today:** read the daily encouragement and open the Daily Text on jw.org.
- **My Routine:** set times and tick the five daily habits.
- **Bible & Study:** enter the Bible passage and lesson learned, then save.
- **Student Life:** read practical tips and scripture references.
- **Progress:** review today's checklist and write a weekly reflection.

## Privacy
This version does not need an account or server. Your notes and checklist are stored in the browser's local storage on that device. Clearing browser/site data can erase them. They do not automatically sync to another phone.

## Editing
You can edit `index.html` using a phone text/code editor. The links point to jw.org. Daily encouragements are sample messages and scripture excerpts; the app opens jw.org for the current official Daily Text.
